# SPDX-License-Identifier: GPL-2.0-or-later
"""Small MQTT 3.1.1 publisher (QoS 0/1, retain, last will, user/password, TLS) - only the standard library.

It only publishes. A connection thread cares for connecting, keep alive and reconnecting.
"""

from __future__ import annotations

import logging
import select
import socket
import ssl
import struct
import threading
import time

log = logging.getLogger("amis.mqtt")


def _encode_str(s: str | bytes) -> bytes:
    b = s.encode("utf-8") if isinstance(s, str) else s
    return struct.pack(">H", len(b)) + b


def _encode_remaining(n: int) -> bytes:
    out = bytearray()
    while True:
        digit = n % 128
        n //= 128
        if n:
            digit |= 0x80
        out.append(digit)
        if not n:
            return bytes(out)


def build_connect(client_id: str, keepalive: int, username: str = "", password: str = "",
                  will_topic: str = "", will_payload: str = "", will_retain: bool = True) -> bytes:
    flags = 0x02  # clean session
    payload = _encode_str(client_id)
    if will_topic:
        flags |= 0x04
        if will_retain:
            flags |= 0x20
        payload += _encode_str(will_topic) + _encode_str(will_payload)
    if username:
        flags |= 0x80
        payload += _encode_str(username)
        if password:
            flags |= 0x40
            payload += _encode_str(password)
    body = _encode_str("MQTT") + bytes([4, flags]) + struct.pack(">H", keepalive) + payload
    return b"\x10" + _encode_remaining(len(body)) + body


def build_publish(topic: str, payload: str | bytes, qos: int = 0, retain: bool = False, packet_id: int = 0) -> bytes:
    data = payload.encode("utf-8") if isinstance(payload, str) else payload
    body = _encode_str(topic)
    if qos:
        body += struct.pack(">H", packet_id)
    body += data
    return bytes([0x30 | (qos << 1) | (1 if retain else 0)]) + _encode_remaining(len(body)) + body


class MqttPublisher:
    def __init__(self, host: str, port: int = 1883, client_id: str = "amis-pi", username: str = "",
                 password: str = "", tls: bool = False, tls_insecure: bool = False, keepalive: int = 60,
                 status_topic: str = ""):
        self.host, self.port = host, port
        self.client_id = client_id
        self.username, self.password = username, password
        self.tls, self.tls_insecure = tls, tls_insecure
        self.keepalive = max(5, keepalive)
        self.status_topic = status_topic
        self._sock: socket.socket | None = None
        self._send_lock = threading.Lock()
        self._packet_id = 0
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None
        self._connected = threading.Event()

    # --- public ---
    def start(self) -> None:
        self._thread = threading.Thread(target=self._run, name="mqtt", daemon=True)
        self._thread.start()

    def stop(self) -> None:
        self._stop.set()
        sock = self._sock
        if sock:
            try:
                with self._send_lock:
                    if self.status_topic:
                        sock.sendall(build_publish(self.status_topic, "offline", 0, True))
                    sock.sendall(b"\xe0\x00")   # DISCONNECT
            except OSError:
                pass
        if self._thread:
            self._thread.join(timeout=3)

    @property
    def connected(self) -> bool:
        return self._connected.is_set()

    def wait_connected(self, timeout: float) -> bool:
        return self._connected.wait(timeout)

    def publish(self, topic: str, payload: str | bytes, qos: int = 0, retain: bool = False) -> bool:
        sock = self._sock
        if sock is None or not self._connected.is_set():
            return False
        qos = 1 if qos else 0   # QoS 2 is not supported - QoS 1 is used instead
        try:
            with self._send_lock:
                pid = 0
                if qos:
                    self._packet_id = self._packet_id % 65535 + 1
                    pid = self._packet_id
                sock.sendall(build_publish(topic, payload, qos, retain, pid))
            return True
        except OSError as exc:
            log.warning("publish failed: %s", exc)
            return False

    # --- internals ---
    def _connect(self) -> socket.socket:
        sock = socket.create_connection((self.host, self.port), timeout=10)
        if self.tls:
            ctx = ssl.create_default_context()
            if self.tls_insecure:
                ctx.check_hostname = False
                ctx.verify_mode = ssl.CERT_NONE
            sock = ctx.wrap_socket(sock, server_hostname=self.host)
        sock.settimeout(10)
        will_topic = self.status_topic
        sock.sendall(build_connect(self.client_id, self.keepalive, self.username, self.password,
                                   will_topic, "offline"))
        head = self._read_exact(sock, 4)
        if head[0] >> 4 != 2 or head[1] != 2 or head[3] != 0:
            code = head[3] if len(head) == 4 else -1
            sock.close()
            raise ConnectionError("MQTT broker refused the connection (code %s)" % code)
        return sock

    @staticmethod
    def _read_exact(sock: socket.socket, n: int) -> bytes:
        data = b""
        while len(data) < n:
            chunk = sock.recv(n - len(data))
            if not chunk:
                raise ConnectionError("connection closed")
            data += chunk
        return data

    def _read_packet(self, sock: socket.socket) -> tuple[int, bytes]:
        first = self._read_exact(sock, 1)[0]
        mult, length = 1, 0
        while True:
            b = self._read_exact(sock, 1)[0]
            length += (b & 0x7F) * mult
            if not b & 0x80:
                break
            mult *= 128
            if mult > 128 ** 3:
                raise ConnectionError("malformed packet")
        return first, self._read_exact(sock, length) if length else b""

    def _run(self) -> None:
        backoff = 1
        while not self._stop.is_set():
            try:
                sock = self._connect()
            except (OSError, ConnectionError, ssl.SSLError) as exc:
                log.warning("MQTT connect to %s:%d failed: %s (retry in %ds)", self.host, self.port, exc, backoff)
                if self._stop.wait(backoff):
                    return
                backoff = min(backoff * 2, 30)
                continue
            backoff = 1
            self._sock = sock
            self._connected.set()
            log.info("MQTT connected to %s:%d", self.host, self.port)
            if self.status_topic:
                self.publish(self.status_topic, "online", 0, True)
            try:
                self._loop(sock)
            except (OSError, ConnectionError, ssl.SSLError) as exc:
                if not self._stop.is_set():
                    log.warning("MQTT connection lost: %s", exc)
            finally:
                self._connected.clear()
                self._sock = None
                try:
                    sock.close()
                except OSError:
                    pass

    def _loop(self, sock: socket.socket) -> None:
        last_rx = time.monotonic()
        last_tx_ping = time.monotonic()
        sock.settimeout(None)
        while not self._stop.is_set():
            pending = isinstance(sock, ssl.SSLSocket) and sock.pending()
            readable = pending or select.select([sock], [], [], 1.0)[0]
            now = time.monotonic()
            if readable:
                sock.settimeout(10)
                first, body = self._read_packet(sock)
                sock.settimeout(None)
                last_rx = now
                ptype = first >> 4
                if ptype == 3 and (first >> 1) & 3 == 1 and len(body) >= 2:
                    # We do not subscribe, but better be polite
                    tlen = struct.unpack(">H", body[:2])[0]
                    pid = body[2 + tlen:4 + tlen]
                    with self._send_lock:
                        sock.sendall(b"\x40\x02" + pid)
                # PUBACK (4) / PINGRESP (13) / ... need no action
            if now - last_rx > self.keepalive * 1.5:
                raise ConnectionError("keepalive timeout")
            if now - last_tx_ping >= self.keepalive / 2:
                with self._send_lock:
                    sock.sendall(b"\xc0\x00")
                last_tx_ping = now
