# amis-pi – AMIS-Smartmeter-Reader für den Raspberry Pi

Liest den Siemens TD-3511/3512 (NetzOÖ, AMIS) über den IR-Lesekopf und stellt bereit:

- **Zählerstände** (1.8.0, 2.8.0, 3.8.1, 4.8.1, 1.7.0, 2.7.0, 3.7.0, 4.7.0, 1.128.0, Saldo)
- **MQTT** (JSON im gleichen Format wie die ESP-Firmware, Standard-Topic `amis/out`)
- **Fronius-Smartmeter-Emulation** per Modbus/TCP (Port 502, Adresse 1)

- **Web-UI** (Port 8080): Live-Werte, Status, alle Einstellungen, Log, Neustart

Nicht enthalten: Shelly-Emulation, REST-API, Seriennummer-Handshake.
Reines Python (≥ 3.11), keine externen Pakete.

> **Ehrlicher Stand:** Der Dekoder ist gegen die Demo-Daten der Original-Firmware geprüft, und
> die Pipeline (Simulation → MQTT/Modbus) läuft mit 27 automatischen Tests (inkl. Web-UI). **Mit echter Hardware
> (UART, Zähler, Fronius, echter MQTT-Broker, Docker-Image) wurde es noch nicht getestet.**
> Der MQTT-Client ist eine eigene minimale Implementierung (QoS 0/1).

## 1. Raspberry Pi vorbereiten (UART)

Für 8E1 (gerade Parität) wird die **PL011-UART** (`/dev/ttyAMA0`) gebraucht. Die Mini-UART
(`ttyS0`) ist dafür nicht geeignet.

Datei `/boot/firmware/config.txt`:

- Pi 3 / 4 / 400 / Zero W / Zero 2 W: `dtoverlay=disable-bt` (und `sudo systemctl disable hciuart`)
- Pi 5 / 500: `dtparam=uart0=on` (Gerät ist dann `/dev/ttyAMA0`)

Serielle Konsole abschalten: in `/boot/firmware/cmdline.txt` den Eintrag `console=serial0,115200`
entfernen (oder `sudo raspi-config` → Interface Options → Serial Port → Login-Shell: Nein,
Hardware: Ja). Danach neu starten.

Verdrahtung (3,3 V!): Lesekopf-TX → GPIO15 (RXD, Pin 10), Lesekopf-RX → GPIO14 (TXD, Pin 8),
GND → GND, Versorgung wie beim ESP (3,3 V). Alternativ ein USB-TTL-Adapter (`/dev/ttyUSB0`).

## 2. Start mit Docker Compose (empfohlen)

```bash
cd amis-pi
docker compose up -d --build
docker compose logs -f
```

Dann im Browser `http://<pi-ip>:8080` öffnen und unter *Einstellungen* AMIS-Schlüssel, MQTT-Broker
usw. eintragen → **Speichern & anwenden**. Die Einstellungen landen in `./config/config.toml`
und der Dienst startet automatisch mit den neuen Werten neu. Beim ersten Start ohne Schlüssel
zeigt die UI nur den Hinweis, bis er eingetragen ist.

- **Passwort für die Web-UI setzen** (Abschnitt „Web-UI“), solange das Netz nicht vertrauenswürdig ist.
  Ohne Passwort kann jeder im Netz Schlüssel und MQTT-Zugang lesen bzw. ändern (angezeigt werden
  Passwörter und Schlüssel nur maskiert).
- Web-Port/Web-Aktiv-Schalter wirken erst nach `docker compose restart`.
- Ohne Lesekopf zum Ausprobieren: in der UI *Simulation* aktivieren (Demo-Daten), die `devices:`-Zeile
  in `docker-compose.yml` kann dann fehlen.
- Keine `AMIS_*`-Umgebungsvariablen zusammen mit der UI nutzen: sie überschreiben beim Start die Datei
  und würden beim Speichern in die Datei übernommen.

Reichweite prüfen ohne UI: `docker compose run --rm --no-deps amis -c /config/config.toml --once`
(Port 502 muss dafür nicht frei sein; Lesekopf-Gerät wird mitgegeben).

## 3. Ohne Docker (systemd)

```bash
sudo useradd -r -G dialout amis
sudo mkdir -p /opt/amis-pi /etc/amis-pi && sudo chown amis /etc/amis-pi
sudo cp -r amis_pi /opt/amis-pi/
sudo cp amis-pi.service /etc/systemd/system/
sudo systemctl enable --now amis-pi
```

Die Web-UI legt `/etc/amis-pi/config.toml` selbst an. Auch möglich: `python3 -m amis_pi -c config.toml --once`
(wartet bis zu 150 s auf ein Telegramm, gibt es als JSON aus) oder `--simulate`.

## MQTT

- `amis/out`: JSON alle `interval` Sekunden, z. B.
  `{"1.8.0":…,"2.8.0":…,"1.7.0":…,"saldo":…,"time":…,"serialnumber":""}`
  (`key_style = "underscore"` liefert `1_8_0` – praktisch für openHAB/Templates)
- `amis/status`: `online` / `offline` (Last Will, retained)
- Saldo = 1.7.0 − 2.7.0, optional mit `saldo_offset` / `saldo_invert`.

## Fronius

Wechselrichter (Datamanager ≥ 3.28.1-3, gleiches Netz): Einstellungen → Zähler → ggf. vorhandenen
Primärzähler löschen → „Fronius Smart Meter (TCP)“ → IP des Pi eintragen → Scan → OK → speichern.

Register: Port 502, Adresse 1, nur Funktion 3. Leistungen ab 40071, Zählerstände ab 40129
(40130 Einspeisung, 40138 Bezug), Saldo 40097/40098. Ohne gültige Zählerdaten (länger als
`stale_after` s kein Telegramm) wird die Verbindung geschlossen, wie bei der Original-Firmware.
Port 502 darf nicht schon belegt sein.

## Lizenz

GPL-2.0-or-later. Abgeleitet von
[mgerhard74/amis_smartmeter_reader](https://github.com/mgerhard74/amis_smartmeter_reader)
(Protokoll, Registerbelegung, Demo-Daten). Siehe `LICENSE`.

Quelle zur UART-Konfiguration:
[raspberry.tips](https://raspberry.tips/en/raspberrypi-tutorials/enabling-uart-on-raspberry-pi-pl011-vs-mini-uart-2026)
