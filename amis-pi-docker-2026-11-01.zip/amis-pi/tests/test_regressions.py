# SPDX-License-Identifier: GPL-2.0-or-later
"""Failure-path and lifecycle tests, including real HTTP/TCP and Linux PTYs."""
import copy
import json
import os
import socket
import tempfile
import threading
import time
import tomllib
import unittest
from pathlib import Path
from unittest.mock import patch

from amis_pi import config, modbus_fronius as mb, mqtt, reader, telegram
from amis_pi.service import Service
from amis_pi.webui import merge_posted
import test_all as helpers
from test_all import KEY, Modbus, StubBroker, wait_for


class ConfigurationTests(unittest.TestCase):
    def test_multiline_secret_roundtrip(self):
        cfg = config.load(environ={})
        cfg['mqtt']['password'] = ' spaces " \\ \n\tGrÃ¼ÃŸe '
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / 'sub' / 'config.toml'
            config.save(str(path), cfg)
            self.assertEqual(tomllib.loads(path.read_text(encoding='utf8')), cfg)
            self.assertEqual(list(path.parent.glob('.amis-config-*')), [])
            if os.name == 'posix':
                self.assertEqual(path.stat().st_mode & 0o777, 0o600)

    def test_atomic_failure_preserves_previous_config(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = str(Path(tmp) / 'config.toml')
            original = config.load(environ={})
            config.save(path, original)
            new = copy.deepcopy(original)
            new['mqtt']['topic'] = 'changed'
            with patch('amis_pi.config.os.replace', side_effect=PermissionError('test')):
                with self.assertRaises(PermissionError):
                    config.save(path, new)
            self.assertEqual(config.load(path, {}), original)
            self.assertEqual(list(Path(tmp).glob('.amis-config-*')), [])

    def test_boolean_strings_are_not_truthy(self):
        cfg = config.load(environ={})
        cfg['meter']['simulate'] = True
        changed = merge_posted(cfg, {'meter': {'simulate': 'false'}})
        self.assertFalse(changed['meter']['simulate'])
        for value in ('maybe', [], 2):
            with self.subTest(value=value), self.assertRaises(ValueError):
                merge_posted(cfg, {'meter': {'simulate': value}})

    def test_bad_types_and_topics(self):
        original = config.load(environ={})
        original['meter']['simulate'] = True
        for section, name, value in [('meter', 'simulate', 'false'), ('mqtt', 'qos', True),
                                     ('mqtt', 'topic', 'amis/#'), ('mqtt', 'topic', ''),
                                     ('mqtt', 'port', -1), ('meter', 'stale_after', 0)]:
            cfg = copy.deepcopy(original)
            cfg[section][name] = value
            with self.subTest(section=section, name=name), self.assertRaises(ValueError):
                config.validate(cfg)

    def test_ui_can_repair_wrong_types_from_file(self):
        current = config.load(environ={})
        current['meter']['simulate'] = 'false'
        current['mqtt']['port'] = '1883'
        repaired = merge_posted(current, {'meter': {'simulate': True}, 'mqtt': {'port': '1884'}})
        config.validate(repaired)
        self.assertEqual(repaired['mqtt']['port'], 1884)


class ModbusLifecycleTests(unittest.TestCase):
    def test_stop_closes_existing_connections(self):
        srv = mb.FroniusModbusServer('127.0.0.1', 0)
        srv.start()
        port = srv.server_address[1]
        srv.set_values(100, 0, 1, 2)
        with socket.create_connection(('127.0.0.1', port), timeout=2) as client:
            self.assertEqual(Modbus.read(client, 40000, 2)[3][1:], b'SunS')
            srv.stop()
            self.assertEqual(client.recv(1), b'')
        successor = mb.FroniusModbusServer('127.0.0.1', port)
        successor.start()
        successor.stop()

    def test_stale_values_close_request_instead_of_returning_zero(self):
        srv = mb.FroniusModbusServer('127.0.0.1', 0, stale_after=0.05)
        srv.start()
        try:
            srv.set_values(2000, 1000, 1, 2)
            time.sleep(0.08)
            with socket.create_connection(srv.server_address, timeout=2) as client:
                client.sendall(bytes.fromhex('00010000000601039ca10002'))
                self.assertEqual(client.recv(20), b'')
        finally:
            srv.stop()

    def test_failed_start_cleans_service_up(self):
        cfg = config.load(environ={})
        cfg['meter']['simulate'] = True
        with socket.socket() as occupied:
            occupied.bind(('127.0.0.1', 0))
            occupied.listen()
            cfg['modbus'].update(host='127.0.0.1', port=occupied.getsockname()[1])
            svc = Service(cfg)
            with self.assertRaises(OSError):
                svc.run()
            self.assertFalse(svc.reader.is_alive())
            self.assertEqual(svc.modbus.socket.fileno(), -1)


class ReaderLifecycleTests(unittest.TestCase):
    def test_simulation_preserves_real_key(self):
        cfg = config.load(environ={})
        cfg['meter'].update(simulate=True, key='ab' * 16)
        cfg['modbus']['enabled'] = False
        svc = Service(cfg)
        t = threading.Thread(target=svc.run)
        t.start()
        try:
            self.assertTrue(wait_for(lambda: svc.status()['online']))
            self.assertEqual(cfg['meter']['key'], 'ab' * 16)
        finally:
            svc.stop()
            t.join(3)
        self.assertFalse(t.is_alive())
        self.assertFalse(svc.reader.is_alive())

    @unittest.skipUnless(hasattr(os, 'openpty'), 'Linux PTY required')
    def test_configuration_failure_closes_fd(self):
        master, slave = os.openpty()
        r = reader.SerialReader(os.ttyname(slave), KEY, lambda v: None)
        try:
            with patch.object(r, '_configure', side_effect=OSError('unsupported parity')):
                with patch('amis_pi.reader.os.close', wraps=os.close) as closed:
                    with self.assertRaises(OSError):
                        r._open()
                    self.assertEqual(closed.call_count, 1)
            self.assertEqual(r._fd, -1)
            self.assertFalse(r.connected)
        finally:
            os.close(master)
            os.close(slave)

    @unittest.skipUnless(hasattr(os, 'openpty'), 'Linux PTY required')
    def test_disconnected_uart_reports_error_and_stops(self):
        master, slave = os.openpty()
        r = reader.SerialReader(os.ttyname(slave), KEY, lambda v: None)
        r.start()
        try:
            self.assertTrue(wait_for(lambda: r.connected))
            os.close(master)
            master = -1
            self.assertTrue(wait_for(lambda: bool(r.last_error)))
        finally:
            r.stop()
            r.join(2)
            if master >= 0:
                os.close(master)
            os.close(slave)
        self.assertFalse(r.is_alive())


class MqttRecoveryTests(unittest.TestCase):
    def test_qos1_message_is_resent_after_lost_ack(self):
        broker = StubBroker(ack_publishes=False)
        pub = mqtt.MqttPublisher('127.0.0.1', broker.port)
        pub.start()
        try:
            self.assertTrue(pub.wait_connected(3))
            self.assertTrue(pub.publish('test/qos1', 'value', qos=1))
            self.assertTrue(wait_for(lambda: len(broker.publishes) == 1))
            broker.ack_publishes = True
            broker.conn.shutdown(socket.SHUT_RDWR)
            self.assertTrue(wait_for(lambda: len(broker.connects) >= 2, 6))
            self.assertTrue(wait_for(lambda: len(broker.publishes) >= 2))
            self.assertTrue(wait_for(lambda: broker.pubacks >= 1))
        finally:
            pub.stop()
            broker.close()
        self.assertFalse(pub.connected)


class WebRegressionTests(unittest.TestCase):
    _start = helpers.WebUITests._start
    _req = helpers.WebUITests._req

    def test_no_key_still_has_configuration_ui(self):
        from amis_pi.app import App
        cfg = config.load(environ={})
        cfg['web'].update(host='127.0.0.1', port=0)
        app = App(cfg, None)
        t = threading.Thread(target=app.run)
        t.start()
        try:
            self.assertTrue(wait_for(lambda: app.web and app.web.httpd and app.error))
            port = app.web.httpd.server_address[1]
            code, body = self._req(port, 'GET', '/api/status')
            self.assertEqual(code, 200)
            self.assertFalse(json.loads(body)['online'])
            self.assertEqual(self._req(port, 'GET', '/healthz')[0], 503)
        finally:
            app.stop()
            t.join(3)

    def test_health_and_repeated_restart(self):
        with tempfile.TemporaryDirectory() as tmp:
            app, path, port = self._start(tmp)
            readers = []
            for _ in range(3):
                self.assertTrue(wait_for(lambda: app.get_status()['online']))
                self.assertEqual(self._req(port, 'GET', '/healthz')[0], 200)
                svc = app.service
                readers.append(svc.reader)
                self.assertEqual(self._req(port, 'POST', '/api/restart')[0], 200)
                self.assertTrue(wait_for(lambda: app.service is not None and app.service is not svc))
            self.assertTrue(all(not r.is_alive() for r in readers))

    def test_invalid_json_and_disk_error(self):
        with tempfile.TemporaryDirectory() as tmp:
            app, path, port = self._start(tmp)
            for data in ([], 'text', {'mqtt': {'enabled': 'maybe'}}, {'mqtt': {'port': True}}):
                self.assertEqual(self._req(port, 'POST', '/api/config', data)[0], 400)
            before = app.get_cfg()
            with patch('amis_pi.config.save', side_effect=PermissionError('test')):
                self.assertEqual(self._req(port, 'POST', '/api/config', {'mqtt': {'topic': 'new'}})[0], 500)
            self.assertEqual(before, app.get_cfg())

    def test_concurrent_changes_do_not_lose_other_fields(self):
        with tempfile.TemporaryDirectory() as tmp:
            app, path, port = self._start(tmp)
            results = []
            start = threading.Barrier(3)
            def post(data):
                start.wait()
                results.append(self._req(port, 'POST', '/api/config', data)[0])
            workers = [threading.Thread(target=post, args=(data,)) for data in
                       ({'mqtt': {'topic': 'changed/topic'}}, {'mqtt': {'interval': 7}})]
            for worker in workers:
                worker.start()
            start.wait()
            for worker in workers:
                worker.join(5)
            self.assertEqual(results, [200, 200])
            self.assertEqual(app.get_cfg()['mqtt']['topic'], 'changed/topic')
            self.assertEqual(app.get_cfg()['mqtt']['interval'], 7)
            self.assertEqual(config.load(path, {})['mqtt']['topic'], 'changed/topic')


if __name__ == '__main__':
    unittest.main()
