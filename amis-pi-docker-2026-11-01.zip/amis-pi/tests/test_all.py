# SPDX-License-Identifier: GPL-2.0-or-later
import json
import os
import random
import socket
import struct
import sys
import threading
import time
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from amis_pi import aes, config, modbus_fronius as mb, mqtt, reader, telegram  # noqa: E402
from amis_pi.service import Service, build_mqtt_payload  # noqa: E402

KEY = telegram.parse_key(telegram.DEMO_KEY)


def wait_for(cond, timeout=5.0):
    end = time.time() + timeout
    while time.time() < end:
        if cond():
            return True
        time.sleep(0.02)
    return False


class TestAes(unittest.TestCase):
    def test_fips197(self):
        key = bytes.fromhex("000102030405060708090a0b0c0d0e0f")
        ct = bytes.fromhex("69c4e0d86a7b0430d8cdb78070b4c55a")
        self.assertEqual(aes.cbc_decrypt(ct, key, bytes(16)), bytes.fromhex("00112233445566778899aabbccddeeff"))

    def test_against_cryptography(self):
        try:
            from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
        except ImportError:
            self.skipTest("cryptography not installed")
        for _ in range(50):
            k, iv, d = os.urandom(16), os.urandom(16), os.urandom(80)
            dec = Cipher(algorithms.AES(k), modes.CBC(iv)).decryptor()
            self.assertEqual(aes.cbc_decrypt(d, k, iv), dec.update(d) + dec.finalize())


class TestTelegram(unittest.TestCase):
    def test_demo(self):
        v = telegram.decode_frame(telegram.DEMO_FRAME, KEY)
        self.assertEqual(v.values, (10, 11, 12, 13, 14, 15, 16, 17))
        self.assertEqual(v.inkasso, 0)
        self.assertEqual(v.ts, 1766079281)            # 2025-12-18 18:34:41 CET = 17:34:41 UTC
        self.assertEqual(v.saldo_w, -1)

    def test_wrong_key(self):
        with self.assertRaises(telegram.TelegramError) as cm:
            telegram.decode_frame(telegram.DEMO_FRAME, bytes(16))
        self.assertTrue(cm.exception.wrong_key)

    def test_bad_checksum_is_not_a_key_problem(self):
        frame = bytearray(telegram.DEMO_FRAME)
        frame[30] ^= 0xFF
        with self.assertRaises(telegram.TelegramError) as cm:
            telegram.decode_frame(bytes(frame), KEY)
        self.assertEqual(cm.exception.code, -7)
        self.assertFalse(cm.exception.wrong_key)

    def test_short_and_garbage(self):
        for data, code in ((b"\x68" * 10, -1), (b"\x00" * 101, -2)):
            with self.assertRaises(telegram.TelegramError) as cm:
                telegram.decode_frame(data, KEY)
            self.assertEqual(cm.exception.code, code)

    def test_dst_bit(self):
        # 2025-07-01 12:00:00 with DST bit -> CEST (+2) = 10:00 UTC
        year = 25
        dt = bytes([0x40, 0, (2 << 5) | 12, 1 | ((year & 0x07) << 5), 7 | ((year & 0x78) << 1), 0])
        self.assertEqual(telegram.cp48_to_unix(dt), 1751364000)  # 2025-07-01T10:00:00Z

    def test_parse_key(self):
        self.assertEqual(telegram.parse_key("0x" + "ab" * 16), bytes([0xAB] * 16))
        for bad in ("", "12", "zz" * 16):
            with self.assertRaises(ValueError):
                telegram.parse_key(bad)


class TestFrameParser(unittest.TestCase):
    def test_chunks_and_garbage(self):
        stream = b"\x00\xff\x10" + telegram.DEMO_DATA + telegram.DEMO_FRAME + b"\x12"
        rnd = random.Random(1)
        for _ in range(30):
            p = reader.FrameParser()
            events, i, now = [], 0, 100.0
            while i < len(stream):
                n = rnd.randint(1, 40)
                events += p.feed(stream[i:i + n], now)
                i += n
                now += 0.01
            kinds = [k for k, _ in events]
            self.assertEqual(kinds, ["nke", "frame", "frame"])
            self.assertEqual(events[1][1], telegram.DEMO_FRAME)

    def test_stale_partial_frame_is_dropped(self):
        p = reader.FrameParser()
        self.assertEqual(p.feed(telegram.DEMO_FRAME[:50], 10.0), [])
        # long pause, then a complete frame: the old half telegram must not break it
        ev = p.feed(telegram.DEMO_FRAME, 20.0)
        self.assertEqual([k for k, _ in ev], ["frame"])


class TestSerialReader(unittest.TestCase):
    @unittest.skipUnless(hasattr(os, "openpty"), "Linux PTY required")
    def test_pty(self):
        master, slave = os.openpty()
        port = os.ttyname(slave)
        got, errs = [], []
        r = reader.SerialReader(port, KEY, got.append, errs.append)
        r.start()
        try:
            time.sleep(0.3)
            os.write(master, telegram.DEMO_DATA)
            self.assertTrue(wait_for(lambda: got), "no values decoded")
            self.assertEqual(got[0].values, (10, 11, 12, 13, 14, 15, 16, 17))
            # expect one ACK for SND_NKE and one for the data telegram
            acks = b""
            end = time.time() + 2
            os.set_blocking(master, False)
            while time.time() < end and len(acks) < 2:
                try:
                    acks += os.read(master, 10)
                except BlockingIOError:
                    time.sleep(0.02)
            self.assertEqual(acks, b"\xe5\xe5")
        finally:
            r.stop()
            r.join(2)
            os.close(master)
            os.close(slave)


class Modbus:
    @staticmethod
    def read(sock, first, count, unit=1, fc=3, tid=0x0A):
        sock.sendall(struct.pack(">HHHBBHH", tid, 0, 6, unit, fc, first, count))
        head = b""
        while len(head) < 9:
            head += sock.recv(9 - len(head))
        rtid, pid, length, runit, rfc = struct.unpack(">HHHBB", head[:8])
        rest = b""
        while len(rest) < length - 3:
            rest += sock.recv(length - 3 - len(rest))
        return rtid, runit, rfc, head[8:9] + rest


class TestModbus(unittest.TestCase):
    def setUp(self):
        self.srv = mb.FroniusModbusServer("127.0.0.1", 0, stale_after=5)
        self.srv.start()
        self.port = self.srv.server_address[1]

    def tearDown(self):
        self.srv.stop()

    def conn(self):
        return socket.create_connection(("127.0.0.1", self.port), timeout=3)

    def test_static_header(self):
        regs = mb.build_registers(0, 0, 0, 0)
        raw = struct.pack(">71H", *regs[:71])
        self.assertEqual(raw[:4], b"SunS")
        self.assertEqual(regs[2], 1)       # DID common model
        self.assertEqual(regs[3], 65)      # length
        self.assertEqual("".join(chr(r) for r in regs[4:15]), "Amis Reader")
        self.assertEqual("".join(chr(r) for r in regs[20:35]), "Smart Meter 63A")
        self.assertEqual(regs[68], 240)
        self.assertEqual(regs[69], 213)    # SunSpec model 213: 3 phase meter (float)
        self.assertEqual(regs[70], 124)
        self.assertEqual(regs[196], 0xFFFF)

    def test_values(self):
        self.srv.set_values(import_w=1500, export_w=300, import_wh=123456, export_wh=654321)
        with self.conn() as s:
            tid, unit, fc, payload = Modbus.read(s, 40097, 2, unit=7, tid=0x1234)
            self.assertEqual((tid, unit, fc), (0x1234, 7, 3))
            self.assertEqual(payload[0], 4)
            self.assertAlmostEqual(struct.unpack(">f", payload[1:5])[0], 1200.0)   # total power = saldo
            _, _, _, p = Modbus.read(s, 40129, 2)
            self.assertAlmostEqual(struct.unpack(">f", p[1:5])[0], 654321.0)       # 2.8.0 export
            _, _, _, p = Modbus.read(s, 40137, 2)
            self.assertAlmostEqual(struct.unpack(">f", p[1:5])[0], 123456.0)       # 1.8.0 import
            _, _, _, p = Modbus.read(s, 40079, 2)
            self.assertAlmostEqual(struct.unpack(">f", p[1:5])[0], 230.0)
            _, _, _, p = Modbus.read(s, 40073, 2)
            self.assertAlmostEqual(struct.unpack(">f", p[1:5])[0], 1200 / 690, places=3)
            # a block read as the Fronius does (58 regs from 40071)
            _, _, _, p = Modbus.read(s, 40070, 58)
            self.assertEqual(p[0], 116)
            self.assertEqual(len(p), 117)

    def test_errors(self):
        self.srv.set_values(1, 2, 3, 4)
        with self.conn() as s:
            self.assertEqual(Modbus.read(s, 40000, 1, fc=4)[2], 0x84)      # function not supported
            self.assertEqual(Modbus.read(s, 40196, 2)[3], b"\x02")          # out of range
            self.assertEqual(Modbus.read(s, 39999, 1)[3], b"\x02")
            self.assertEqual(Modbus.read(s, 40000, 0)[3], b"\x03")          # count 0
            # server is still alive afterwards
            self.assertEqual(Modbus.read(s, 40000, 2)[3][1:], b"SunS")

    def test_two_requests_in_one_segment(self):
        self.srv.set_values(1, 2, 3, 4)
        with self.conn() as s:
            s.sendall(struct.pack(">HHHBBHH", 1, 0, 6, 1, 3, 40000, 2) + struct.pack(">HHHBBHH", 2, 0, 6, 1, 3, 40002, 1))
            data = b""
            while len(data) < 13 + 11:
                data += s.recv(64)
            self.assertEqual(data[:2], b"\x00\x01")
            self.assertEqual(data[13:15], b"\x00\x02")

    def test_closes_without_valid_data(self):
        with self.conn() as s:
            s.sendall(struct.pack(">HHHBBHH", 1, 0, 6, 1, 3, 40000, 2))
            self.assertEqual(s.recv(10), b"")        # closed like the firmware does
        self.srv.set_values(1, 2, 3, 4)
        self.assertTrue(self.srv.valid())
        self.srv.invalidate()
        self.assertFalse(self.srv.valid())


class StubBroker(threading.Thread):
    """Very small MQTT broker: remembers CONNECT and PUBLISH packets."""

    def __init__(self, accept_connect=True, ack_publishes=True):
        super().__init__(daemon=True)
        self.srv = socket.socket()
        self.srv.bind(("127.0.0.1", 0))
        self.srv.listen(5)
        self.port = self.srv.getsockname()[1]
        self.connects, self.publishes = [], []
        self.pubacks = 0
        self.conn = None
        self.lock = threading.Lock()
        self.accept_connect = accept_connect
        self.ack_publishes = ack_publishes
        self.srv.settimeout(0.2)
        self.stopping = threading.Event()
        self.start()

    @staticmethod
    def _read(sock, n):
        d = b""
        while len(d) < n:
            c = sock.recv(n - len(d))
            if not c:
                raise EOFError
            d += c
        return d

    def run(self):
        while not self.stopping.is_set():
            try:
                conn, _ = self.srv.accept()
            except socket.timeout:
                continue
            except OSError:
                return
            self.conn = conn
            try:
                while True:
                    first = self._read(conn, 1)[0]
                    mult, length = 1, 0
                    while True:
                        b = self._read(conn, 1)[0]
                        length += (b & 0x7F) * mult
                        mult *= 128
                        if not b & 0x80:
                            break
                    body = self._read(conn, length) if length else b""
                    t = first >> 4
                    if t == 1:
                        with self.lock:
                            self.connects.append(body)
                        conn.sendall(b"\x20\x02\x00" + (b"\x00" if self.accept_connect else b"\x05"))
                    elif t == 3:
                        tl = struct.unpack(">H", body[:2])[0]
                        topic = body[2:2 + tl].decode()
                        qos = (first >> 1) & 3
                        off = 2 + tl
                        pid = None
                        if qos:
                            pid = body[off:off + 2]
                            off += 2
                            if self.ack_publishes:
                                conn.sendall(b"\x40\x02" + pid)
                                self.pubacks += 1
                        with self.lock:
                            self.publishes.append((topic, body[off:].decode(), qos, bool(first & 1)))
                    elif t == 12:
                        conn.sendall(b"\xd0\x00")
            except (EOFError, OSError):
                pass
            finally:
                conn.close()

    def close(self):
        self.stopping.set()
        self.srv.close()
        if self.conn:
            try:
                self.conn.close()
            except OSError:
                pass


class TestMqtt(unittest.TestCase):
    def test_publish_and_will(self):
        broker = StubBroker()
        try:
            c = mqtt.MqttPublisher("127.0.0.1", broker.port, "cid", "user", "pw", status_topic="amis/status")
            c.start()
            self.assertTrue(c.wait_connected(5))
            self.assertTrue(c.publish("a/b", '{"x":1}', qos=0, retain=True))
            self.assertTrue(c.publish("a/c", "hi", qos=1))
            self.assertTrue(wait_for(lambda: len(broker.publishes) >= 3))
            self.assertEqual(broker.publishes[0], ("amis/status", "online", 1, True))
            self.assertEqual(broker.publishes[1], ("a/b", '{"x":1}', 0, True))
            self.assertEqual(broker.publishes[2], ("a/c", "hi", 1, False))
            body = broker.connects[0]
            self.assertEqual(body[:6], b"\x00\x04MQTT")
            flags = body[7]
            self.assertEqual(flags & 0xE6, 0x80 | 0x40 | 0x20 | 0x04 | 0x02)   # user, pw, will retain, will, clean
            self.assertIn(b"amis/status", body)
            self.assertIn(b"offline", body)
            c.stop()
        finally:
            broker.close()

    def test_refused_and_retry(self):
        broker = StubBroker(accept_connect=False)
        try:
            c = mqtt.MqttPublisher("127.0.0.1", broker.port, "cid")
            c.start()
            self.assertFalse(c.wait_connected(1.5))
            self.assertFalse(c.publish("x", "y"))
            c.stop()
        finally:
            broker.close()



class TestConfig(unittest.TestCase):
    def test_env_override(self):
        cfg = config.load(None, {"AMIS_MQTT_HOST": "broker", "AMIS_MQTT_PORT": "1884",
                                 "AMIS_MODBUS_ENABLED": "false", "AMIS_METER_KEY": "ab" * 16})
        self.assertEqual(cfg["mqtt"]["host"], "broker")
        self.assertEqual(cfg["mqtt"]["port"], 1884)
        self.assertFalse(cfg["modbus"]["enabled"])
        self.assertEqual(cfg["meter"]["key"], "ab" * 16)

    def test_unknown_option(self):
        import tempfile
        with tempfile.NamedTemporaryFile("w", suffix=".toml", delete=False) as fh:
            fh.write("[mqtt]\nhots = 'x'\n")
        try:
            with self.assertRaises(ValueError):
                config.load(fh.name, {})
        finally:
            os.unlink(fh.name)

    def test_payload_styles(self):
        v = telegram.decode_frame(telegram.DEMO_FRAME, KEY)
        cfg = config.load(None, {})
        d = json.loads(build_mqtt_payload(v, cfg, "SN1"))
        self.assertEqual(d["1.8.0"], 10)
        self.assertEqual(d["saldo"], -1)
        self.assertEqual(d["serialnumber"], "SN1")
        cfg["mqtt"].update(key_style="underscore", saldo_offset=5, saldo_invert=True)
        d = json.loads(build_mqtt_payload(v, cfg))
        self.assertEqual(d["2_8_0"], 11)
        self.assertEqual(d["saldo"], 6)       # -(14 - 15 - 5)
        self.assertIn("1_128_0", d)


class TestEndToEnd(unittest.TestCase):
    def test_simulation(self):
        broker = StubBroker()
        cfg = config.load(None, {})
        cfg["meter"]["simulate"] = True
        cfg["mqtt"].update(enabled=True, host="127.0.0.1", port=broker.port, interval=1)
        cfg["modbus"].update(host="127.0.0.1", port=0)
        svc = Service(cfg)
        t = threading.Thread(target=svc.run, daemon=True)
        t.start()
        try:
            self.assertTrue(wait_for(lambda: any(p[0] == "amis/out" for p in broker.publishes), 8))
            msg = json.loads([p for p in broker.publishes if p[0] == "amis/out"][0][1])
            self.assertEqual(msg["1.8.0"], 10)
            self.assertEqual(msg["time"], 1766079281)
            port = svc.modbus.server_address[1]
            with socket.create_connection(("127.0.0.1", port), timeout=3) as s:
                _, _, _, p = Modbus.read(s, 40137, 2)
                self.assertAlmostEqual(struct.unpack(">f", p[1:5])[0], 10.0)
        finally:
            svc.stop()
            t.join(5)
            broker.close()




class WebUITests(unittest.TestCase):
    def _start(self, tmp, **web):
        import json as _json
        from amis_pi import config as cfgmod
        from amis_pi.app import App
        path = os.path.join(tmp, "config.toml")
        cfg = cfgmod.load(None, {})
        cfg["meter"]["simulate"] = True
        cfg["mqtt"]["enabled"] = False
        import socket
        with socket.socket() as sk:
            sk.bind(("127.0.0.1", 0))
            cfg["modbus"]["port"] = sk.getsockname()[1]
        with socket.socket() as sk:
            sk.bind(("127.0.0.1", 0))
            cfg["web"].update(host="127.0.0.1", port=sk.getsockname()[1], **web)
        app = App(cfg, path)
        t = threading.Thread(target=app.run, daemon=True)
        t.start()
        deadline = time.time() + 5
        while (app.web is None or app.web.httpd is None or app.service is None) and time.time() < deadline:
            time.sleep(0.05)
        self.addCleanup(lambda: (app.stop(), t.join(5)))
        return app, path, app.web.httpd.server_address[1]

    def _req(self, port, method, path, body=None, auth=None):
        import urllib.request, urllib.error, json as _json, base64
        req = urllib.request.Request("http://127.0.0.1:%d%s" % (port, path), method=method,
                                     data=_json.dumps(body).encode() if body is not None else None)
        if auth:
            req.add_header("Authorization", "Basic " + base64.b64encode(auth.encode()).decode())
        try:
            with urllib.request.urlopen(req, timeout=5) as r:
                return r.status, r.read()
        except urllib.error.HTTPError as e:
            return e.code, e.read()

    def test_status_page_and_save(self):
        import json as _json, tempfile, tomllib
        with tempfile.TemporaryDirectory() as tmp:
            app, path, port = self._start(tmp)
            st, body = self._req(port, "GET", "/")
            self.assertEqual(st, 200)
            self.assertIn(b"AMIS", body)
            deadline = time.time() + 6
            while time.time() < deadline:
                st, body = self._req(port, "GET", "/api/status")
                s = _json.loads(body)
                if s["online"]:
                    break
                time.sleep(0.2)
            self.assertTrue(s["online"])
            self.assertEqual(s["values"]["obis"]["1.8.0"], 10)
            old = app.service
            st, body = self._req(port, "POST", "/api/config",
                                 {"mqtt": {"topic": "x/y", "interval": "5"}, "meter": {"key": "********"}})
            self.assertEqual(st, 200, body)
            with open(path, "rb") as fh:
                saved = tomllib.load(fh)
            self.assertEqual(saved["mqtt"]["topic"], "x/y")
            self.assertEqual(saved["mqtt"]["interval"], 5)
            deadline = time.time() + 6
            while app.service is old and time.time() < deadline:
                time.sleep(0.1)
            self.assertIsNot(app.service, old)        # service was restarted with the new config

    def test_invalid_config_rejected(self):
        import tempfile
        with tempfile.TemporaryDirectory() as tmp:
            app, path, port = self._start(tmp)
            st, body = self._req(port, "POST", "/api/config", {"mqtt": {"qos": 2}})
            self.assertEqual(st, 400)
            st, body = self._req(port, "POST", "/api/config", {"nope": {"a": 1}})
            self.assertEqual(st, 400)
            self.assertFalse(os.path.exists(path))

    def test_basic_auth_and_masking(self):
        import json as _json, tempfile
        with tempfile.TemporaryDirectory() as tmp:
            app, path, port = self._start(tmp, password="geheim", username="admin")
            self.assertEqual(self._req(port, "GET", "/api/status")[0], 401)
            self.assertEqual(self._req(port, "GET", "/api/status", auth="admin:falsch")[0], 401)
            st, body = self._req(port, "GET", "/api/config", auth="admin:geheim")
            self.assertEqual(st, 200)
            self.assertNotIn(b"geheim", body)
            self.assertEqual(_json.loads(body)["web"]["password"], "********")

    def test_bad_key_does_not_kill_app(self):
        import json as _json, tempfile
        with tempfile.TemporaryDirectory() as tmp:
            app, path, port = self._start(tmp)
            st, body = self._req(port, "POST", "/api/config", {"meter": {"simulate": False, "key": "abc"}})
            self.assertEqual(st, 400)               # rejected by validation, old service keeps running
            self.assertIsNotNone(app.service)


if __name__ == "__main__":
    unittest.main()
